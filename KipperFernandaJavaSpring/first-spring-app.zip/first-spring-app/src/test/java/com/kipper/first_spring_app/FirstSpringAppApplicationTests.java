package com.kipper.first_spring_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
